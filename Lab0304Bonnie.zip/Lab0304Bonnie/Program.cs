﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab0304Bonnie
{
    // Bonnie Ives de Castro Nunes
    // Worked on 2023-01-26
    struct Person
    {
        public string fName;
        public string lName;
        public sbyte age;

        public Person(string studentfName, string studentlName, sbyte studentAge)
        {
            fName = studentfName;
            lName = studentlName;
            age = studentAge;
        }
    }
    struct Student
    {
        public Person person;
        public UInt32 sId;
        public string cName;
        public string cAddress;
        public string cCity;

        public Student(Person personName, UInt32 studentPerson, string studentCName, string studentCAddress, string studentCCity)
        {
            person = personName;
            sId = studentPerson;
            cName = studentCName;
            cAddress = studentCAddress;
            cCity = studentCCity;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creating the objects
            Student[] studentArray = new Student[5];
            List<Student> studentList = new List<Student>();

            // Declaring some variables
            int option;
            int counterArray = 1;
            int counterList = 0;

            // Hardcoding the first student
            studentArray[0].person.fName = "Bonnie Ives";
            studentArray[0].person.lName = "de Castro Nunes";
            studentArray[0].person.age = 39;
            studentArray[0].sId = 1234567;
            studentArray[0].cName = "LaSalle";
            studentArray[0].cAddress = "2000 Ste. Catherine";
            studentArray[0].cCity = "Montreal";

            do
            {
                // Testing the size of the array
                int arraySize = studentArray.Count();

                // Showing the number of student stored
                Console.WriteLine("Number of students. On list: {0} | On array: {1}", counterList, counterArray);

                // Display the options
                option = Convert.ToInt16(Option());

                // Block to store and to display informations about students
                switch (option)
                {
                    case 1:
                        {
                            try
                            {
                                // Adding new student information into the array
                                Console.WriteLine("Inform student's first name:");
                                studentArray[counterArray].person.fName = StudentFName();

                                Console.WriteLine("Inform student's last name:");
                                studentArray[counterArray].person.lName = StudentLName();

                                Console.WriteLine("Inform student's age.");
                                Console.WriteLine("(Must be between 18 and 65):");
                                studentArray[counterArray].person.age = Age();

                                Console.WriteLine("Inform student's ID.");
                                Console.WriteLine("(Must have 7 digits):");
                                studentArray[counterArray].sId = SID();

                                Console.WriteLine("Inform college name:");
                                studentArray[counterArray].cName = CName();

                                Console.WriteLine("Inform college address:");
                                studentArray[counterArray].cAddress = CAddress();

                                Console.WriteLine("Inform college city:");
                                studentArray[counterArray].cCity = CCity();

                                counterArray++;
                            }
                            catch (Exception exArray)
                            {
                                Console.WriteLine(exArray.Message);
                                Console.WriteLine("You cannot insert other student into this array.");
                            }
                            break;
                        }
                    case 2:
                        {
                            // Adding new student information into the array
                            Console.WriteLine("Inform student's first name:");
                            string fNameTemp = StudentFName();

                            Console.WriteLine("Inform student's last name:");
                            string lNameTemp = StudentLName();

                            Console.WriteLine("Inform student's age.");
                            Console.WriteLine("(Must be between 18 and 65):");
                            sbyte ageTemp = Age();

                            Console.WriteLine("Inform student's ID.");
                            Console.WriteLine("(Must have 7 digits):");
                            UInt32 sIdTemp = SID();

                            Console.WriteLine("Inform college name:");
                            string cNameTemp = CName();

                            Console.WriteLine("Inform college address:");
                            string cAddressTemp = CAddress();

                            Console.WriteLine("Inform college city:");
                            string cCityTemp = CCity();

                            studentList.Add(new Student(new Person(fNameTemp, lNameTemp, ageTemp), sIdTemp, cNameTemp, cAddressTemp, cCityTemp));

                            counterList++;
                            break;
                        }
                    case 3: // Modify this to use interpolation $"{}".
                        {
                            // If the counter is equal to 0, this information will be displayed
                            if (counterArray == 0)
                            {
                                Console.WriteLine("There is no information stored into the array.\n");
                                Console.WriteLine();
                            }
                            // When we have at least one information stored, a loop is started showing
                            // in sequence every student information. 
                            else
                            {
                                int counter1 = 0;
                                foreach (Student student in studentArray)
                                {
                                    Console.WriteLine($"INFO FOR STUDENT NUMBER: {(counter1 + 1)}");
                                    Console.WriteLine("----------------------------");
                                    Console.WriteLine($"| Student's first name: {student.person.fName,-15} | Student's last name: {student.person.lName,-15}| Student's age: {student.person.age,3} |");
                                    Console.WriteLine($"| Student's ID: {student.sId,10} | College Name: {student.cName,-10}| College Address: {student.cAddress,-20} | College city: {student.cCity,-15} |\n");
                                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------");
                                    counter1++;
                                }
                            }
                            break;
                        }
                    case 4:
                        {
                            // If the counter is equal to 0, this information will be displayed
                            if (counterList == 0)
                            {
                                Console.WriteLine("There is no information stored into the list.\n");
                                Console.WriteLine();
                            }
                            // When we have at least one information stored, a loop is started showing
                            // in sequence every student information. 
                            else
                            {
                                int counter2 = 0;
                                foreach (Student student in studentList)
                                {
                                    Console.WriteLine("INFO FOR STUDENT NUMBER: {0}", (counter2 + 1));
                                    Console.WriteLine("----------------------------");
                                    Console.WriteLine("| Student's first name: {0,-15} | Student's last name: {1,-15}| Student's age: {2,3} |",
                                        student.person.fName, student.person.lName, student.person.age);
                                    Console.WriteLine("| Student's ID: {0,10} | College Name: {1,-10}| College Address: {2,-20} | College city: {3,-15} |\n",
                                        student.sId, student.cName, student.cAddress, student.cCity);
                                    Console.WriteLine("======================================================================================================================");
                                    counter2++;
                                }
                            }
                            break;
                        }
                    case 5:
                        {
                            studentList.AddRange(studentArray);
                            Console.WriteLine("Students from array added to list.\n");
                            counterList = studentArray.Length + counterList;
                            break;
                        }
                    case 6:
                        {
                            studentList.Clear();
                            Console.WriteLine("List cleared.\n");
                            counterList= 0;
                            break;
                        }                   
                    case 7:
                        {
                            Console.WriteLine("You exited the application.\n");
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Unknown option. Try again.\n");
                            break;
                        }
                }
            }
            while (option != 7);

            Console.WriteLine("Please press any key to close the window.");
            Console.ReadKey();
        }
        public static Int16 Option()
        {
            Int16 option;

        // This function is made to display the options

        opt1: Console.WriteLine("Please choose one option: ");
            Console.WriteLine("--------------------------");
            Console.WriteLine("\t(1) Insert new student into the array.");
            Console.WriteLine("\t(2) Insert new student into the list.");
            Console.WriteLine("\t(3) Display students on the array.");
            Console.WriteLine("\t(4) Display students on the list.");
            Console.WriteLine("\t(5) Add array into the list.");
            Console.WriteLine("\t(6) Clear the list.");
            Console.WriteLine("\t(7) Quit the application.");
            Console.Write("\nYour option: ");

            // Validation of the conversion. If the more than one character is informed,
            // The exception message will be displayed.
            try
            {
                option = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine();
            }
            catch (Exception opt)
            {
                Console.WriteLine(opt.Message);
                goto opt1;
            }
            return option;
        }
        public static string StudentFName()
        {
            // Using this function to read student's first name
            string fName;
            fName = Console.ReadLine();
            Console.WriteLine();

            return fName;
        }
        public static string StudentLName()
        {
            // Using this function to read student's last name
            string lName;
            lName = Console.ReadLine();
            Console.WriteLine();

            return lName;
        }
        public static sbyte Age()
        {
        // Using this function to read student's age
        age2:
            sbyte age = 0;

            // Validation of the conversion. If the range is different than -128 to +127 is informed,
            // The exception message will be displayed.
            try
            {
                age = Convert.ToSByte(Console.ReadLine());
                Console.WriteLine();

                // If the age informed is not inside the range of 18 and 65, the message
                // will displayed and the age must be read again
                while (age < 18 || age > 65)
                {
                    Console.WriteLine("Invalid age. Must be between 18 and 65.");
                    age = Convert.ToSByte(Console.ReadLine());
                }
            }
            catch (Exception age1)
            {
                Console.WriteLine(age1.Message);
                Console.WriteLine("Please try again.");
                goto age2;
            }

            return age;
        }
        public static UInt32 SID()
        {
        // Using this function to read the student's ID. 
        sid2:
            UInt32 sId;

            // If the number inform is outside of the range from 0 to 4,294,967,295 , the exception message will be shown.
            try
            {
                sId = Convert.ToUInt32(Console.ReadLine());
                Console.WriteLine();

                // If the number doesn't have 7 digit, which is outside of the range between
                // 1,000,000 and 9,999,999 , this message will be shown and the user must
                // inform the right interval.
                while (sId < 1000000 || sId > 9999999)
                {
                    Console.WriteLine("Invalid student ID. Must have 7 digits.");
                    sId = Convert.ToUInt32(Console.ReadLine());
                }
            }
            catch (Exception sid1)
            {
                Console.WriteLine(sid1.Message);
                Console.WriteLine("Please try again.");
                goto sid2;
            }
            return sId;
        }
        public static string CName()
        {
            // Using this function to read the college name.
            string cName;
            cName = Console.ReadLine();
            Console.WriteLine();

            return cName;
        }
        public static string CAddress()
        {
            // Using this function to read the college address
            string cAddress;
            cAddress = Console.ReadLine();
            Console.WriteLine();

            return cAddress;
        }
        public static string CCity()
        {
            // Using this function to read the college city
            string cCity;
            cCity = Console.ReadLine();
            Console.WriteLine();

            return cCity;
        }
    }
}

